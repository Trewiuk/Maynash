﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace kursovayaMaynashev
{
    /// <summary>
    /// Логика взаимодействия для ReadRecordPage.xaml
    /// </summary>
    public partial class ReadRecordPage : Page
    {
        private static MaynashEntities _context;
        public ReadRecordPage()
        {
            InitializeComponent();
        }
        public static MaynashEntities GetContext()
        {
            if (_context == null)
                _context = new MaynashEntities();
            return _context;
        }
        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                MaynashEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DataGridReadRecord.ItemsSource = MaynashEntities.GetContext().Record.ToList();
            }
        }

        private void DataGridReadRecord_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new RecordPage((sender as Button).DataContext as Record));
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            var RecordForRemoving = DataGridReadRecord.SelectedItems.Cast<Record>().ToList();

            if (MessageBox.Show($"Вы точно хотите удалить следующие {RecordForRemoving.Count()}элементов ?", "Внимание",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    MaynashEntities.GetContext().Record.RemoveRange(RecordForRemoving);
                    MaynashEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены! ");
                    DataGridReadRecord.ItemsSource = MaynashEntities.GetContext().Record.ToList();

                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }
    }
}
